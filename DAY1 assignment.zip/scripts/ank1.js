/*Question 2 :
Write the difference between var, let and const with code examples*/

//var
var x = 14;
x = 12;
console.log(x);
//let
var x = 14;
x = 12;
console.log(x);
//const
const y = 14;
y = 12;
console.log(y);