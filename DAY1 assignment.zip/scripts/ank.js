/*Question 1 :
Explore and explain the various methods in console function
Explain them
Ex. console.log()
console.warn().
etc...*/
//log()
console.log('abc'); 
//error()
console.error('This is a simple error');
//warn  
console.warn('This is a warning.');  
//clear  
console.clear();
//table()
console.table({'a':1, 'b':2}); 
//count
for(let i=0;i<5;i++){ 
    console.count(i); 
} 

