/*Question 3 :
Write a brief intro on available data types in Javascript.*/
//Number
let num=25;
console.log(num);
//string
let str="Ankita"
console.log(str);
//boolean
let bool=true;
console.log(bool);
//bignit
let num1=123456789n;
console.log(num1);
//null
let nullvar=null;
console.log(nullvar);
//undefined
let m=undefined;
console.log(m);
//array
let fruits=['apple','mango','banana','orange'];
console.log(fruits);
//function
let hii = function(){ 
    return "Hello World!"; 
}
console.log(hii());

